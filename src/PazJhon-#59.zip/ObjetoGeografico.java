public class ObjetoGeografico {
    private String name, muni;
    private Double id;

    
    public ObjetoGeografico(){
    }


    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setMuni(String muni) {
        this.muni = muni;
    }

    public String getMuni() {
        return muni;
    }

    public void setId(Double id) {
        this.id = id;
    }

    public Double getId() {
        return id;
    }
}